import { SideObject } from "../types";
export default function getFreshSideObject(): SideObject;
