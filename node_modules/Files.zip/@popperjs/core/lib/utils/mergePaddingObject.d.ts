import { SideObject } from "../types";
export default function mergePaddingObject(paddingObject: Partial<SideObject>): SideObject;
