declare function isElement(node: any): boolean;
declare function isHTMLElement(node: any): boolean;
declare function isShadowRoot(node: any): boolean;
export { isElement, isHTMLElement, isShadowRoot };
