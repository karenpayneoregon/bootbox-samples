export default function getViewportRect(element: Element): {
    width: number;
    height: number;
    x: number;
    y: number;
};
